-- Vortex Hub: carregador do módulo ADM separado
-- Troque a URL abaixo pela URL RAW do seu repositório do painel.
-- Coloque este trecho no Vortex Hub depois da inicialização de Players/LocalPlayer.

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

local ADMIN_MODULE_URL = "COLE_AQUI_A_URL_RAW_DO_SEU_ADMIN_PANEL_LUA"

local ADMINS = {
    ["hoangvanhieuCc_39"] = true,
    ["luke_jokerHk3"] = true,
    ["Marcosjjunioioe123"] = true,
    ["Tokitooff29"] = true,
    ["biadofrostzin_7"] = true,
}

if ADMINS[LocalPlayer.Name] then
    task.spawn(function()
        local ok, err = pcall(function()
            assert(ADMIN_MODULE_URL:match("^https://"), "Configure a URL RAW do módulo ADM")
            local source = game:HttpGet(ADMIN_MODULE_URL)
            assert(type(source) == "string" and #source > 0, "O módulo ADM veio vazio")
            local chunk, compileErr = loadstring(source)
            assert(chunk, compileErr or "Falha ao compilar o módulo ADM")
            chunk()
        end)

        if not ok then
            warn("[Vortex ADM] Falha ao carregar painel: " .. tostring(err))
        end
    end)
else
    print("[Vortex ADM] Painel não carregado: usuário não autorizado.")
end
