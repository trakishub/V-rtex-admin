VORTEX ADM — REPOSITÓRIO SEPARADO

Arquivos:
- loader.lua: trecho que fica no Vortex Hub principal.
- admin_panel.lua: módulo independente do painel.

CONFIGURAÇÃO
1. Crie um repositório no GitHub, por exemplo Vortex-Admin.
2. Envie admin_panel.lua para esse repositório.
3. Abra o arquivo no GitHub e toque em Raw.
4. Copie a URL RAW e cole em ADMIN_MODULE_URL dentro de loader.lua.
5. Cole o trecho de loader.lua no script principal depois de obter Players e LocalPlayer.
6. Teste primeiro com a sua conta autorizada.

IMPORTANTE
- O exemplo só cria um aviso de confirmação; ele é um esqueleto para validar o carregamento.
- Transfira a interface real em etapas, conferindo dependências e erros.
- Uma lista de nomes dentro de um script público não é segurança forte: qualquer pessoa pode ler/alterar o código local. Para controle de acesso real, use validação no servidor que você controla.
- Não inclua webhook secreto, tokens, senhas ou dados privados no repositório.
- Use comandos administrativos apenas em experiências e situações em que você tenha autorização.
