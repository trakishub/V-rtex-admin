-- Vortex Admin Panel - módulo independente
-- Este arquivo deve conter somente a interface e funções administrativas autorizadas.
-- O módulo obtém LocalPlayer por conta própria para não depender de variáveis locais
-- do script principal.

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

assert(LocalPlayer, "[Vortex ADM] LocalPlayer não encontrado")

local function criarAviso(texto)
    local playerGui = LocalPlayer:WaitForChild("PlayerGui")
    local antigo = playerGui:FindFirstChild("VortexAdminNotice")
    if antigo then antigo:Destroy() end

    local gui = Instance.new("ScreenGui")
    gui.Name = "VortexAdminNotice"
    gui.ResetOnSpawn = false
    gui.Parent = playerGui

    local frame = Instance.new("Frame")
    frame.Size = UDim2.fromOffset(320, 70)
    frame.Position = UDim2.new(0.5, -160, 0, 30)
    frame.BackgroundColor3 = Color3.fromRGB(20, 20, 28)
    frame.BorderSizePixel = 0
    frame.Parent = gui

    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 12)
    corner.Parent = frame

    local label = Instance.new("TextLabel")
    label.BackgroundTransparency = 1
    label.Size = UDim2.new(1, -20, 1, -10)
    label.Position = UDim2.fromOffset(10, 5)
    label.Font = Enum.Font.GothamBold
    label.TextSize = 15
    label.TextWrapped = true
    label.TextColor3 = Color3.fromRGB(255, 255, 255)
    label.Text = texto
    label.Parent = frame

    task.delay(4, function()
        if gui.Parent then gui:Destroy() end
    end)
end

criarAviso("Vortex ADM carregado para @" .. LocalPlayer.Name)
print("[Vortex ADM] Módulo carregado com sucesso.")
